package process;

public class ConditionNotFulfilledException extends Exception {


	private static final long serialVersionUID = 1L;

	public ConditionNotFulfilledException() {
		super();
		
	}

	public ConditionNotFulfilledException(String message) {
		super(message);
		
	}

	public ConditionNotFulfilledException(String message, Throwable cause) {
		super(message, cause);
		
	}

	public ConditionNotFulfilledException(Throwable cause) {
		super(cause);
		
	}

}
