package process;

import static javax.swing.WindowConstants.DISPOSE_ON_CLOSE;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Insets;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.EventObject;
import java.util.LinkedList;
import java.util.List;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.Vector;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.JTextArea;
import javax.swing.SpinnerNumberModel;
import javax.swing.UIManager;
import javax.swing.border.EmptyBorder;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

public class Dispatcher implements Runnable {
	/**
	 * Признак работающего диспетчера
	 */
	private boolean starting = false;

	/**
	 * Ссылка на поток выполнения правил действия диспетчера
	 */
	private Thread thread;

	/**
	 * Значение текущего модельного времени Якщо -1, він ще не стартовав
	 */
	private double currentTime;

	/**
	 * Список "актеров", желающих выполнить свои правила действия
	 */
	private Deque<Actor> startList = new ArrayDeque<>();;

	/**
	 * Список "актеров", которые приостановили свои правила действия до выполнения
	 * некоторого условия
	 */
	private List<Actor> waitingActorQueue = new LinkedList<>();

	/**
	 * Список "актеров", которые приостановили свои правила действия до некоторого
	 * момента времени
	 */
	private Queue<Actor> timingActorQueue = 
			new PriorityQueue<>( (a1, a2) -> 
			Double.compare(a1.activateTime, a2.activateTime));

	/**
	 * Имя файла для вывода отладочного протокола работы модели. Имя "Console"
	 * обеспечивает вывод протокола на консоль
	 */
	private String protocolFileName = "";

	/**
	 * Поток вывода протокола в файл
	 */
	private BufferedWriter out;

	private Console frame;

	/**
	 * Список для слушателей события dispatcherStart
	 */
	private Vector<DispatcherStartListener> dispatcherStartListeners;

	/**
	 * Список для слушателей события changeTime
	 */
	private Vector<ChangeTimeListener> changeTimeListeners;

	/**
	 * Список для слушателей события dispatcherFinish
	 */
	private Vector<DispatcherFinishListener> dispatcherFinishListeners;

	/**
	 * Метод для добавления "актера" в список стартующих актеров. Это единственный
	 * способ для "актера" начать выполнение своих правил действия. Метод
	 * обеспечивает "актера" ссылкой на "Диспетчера"
	 * 
	 * @param arr
	 */
	public void addStartingActor(Actor a) {
		a.setDispatcher(this);
		startList.addLast(a);
	}

	/**
	 * Инициализация "Диспетчера" и запуск потока выполнения его правил действия
	 * 
	 */
	public void start() {
		if (starting) {
			System.out.println("Ignore attempt "
					+ "to run Dispatcher again");
			return;
		}
		starting = true;
		thread = new Thread(this, "Dispatcher");
		thread.start();
	}

	/**
	 * Метод интерфейса Runnable. Правила действия "Диспетчера".
	 * 
	 */
	public void run() {
		printToProtocol("Modeling time: " + currentTime);
		// Активізація події DispatcherStart
		fireDispatcherStartEvent();
		// Цикл обробки списків акторів
		while (true) {
			// readyActor - це актор, якого треба активізувати
			// Беремо актора із стартового списку
			Actor readyActor = startList.pollFirst();
			if (readyActor != null) {
				readyActor.start();
				// зупиняємо диспетчера
				readyActor.suspendIndicator.waitForValue(true);;
				continue;
			}
			// Обробка списку акторів, що чекають
			// на виконання умови
			for (Actor a : waitingActorQueue) {
				if (a.getActivateCondition().getAsBoolean()) {
					readyActor = a;
					break;
				}
			}
			if (readyActor != null) {
				waitingActorQueue.remove(readyActor);
				// Якщо readyActor був затриманий на певний час
				timingActorQueue.remove(readyActor);
				// активізуємо актора, для якого виконалася умова
				readyActor.resume();
				continue;
			}
			// Якщо умови невиконалися для жодного з акторів
			// обробляємо список акторів, що затримані на час
			// Беремо актора с найменшим часом активації
			readyActor = timingActorQueue.poll();
			if (readyActor != null) {
				// Можливо readyActor ще чекав виконання умови
				waitingActorQueue.remove(readyActor);
				if(readyActor.activateTime < currentTime) {
					System.out.println(	readyActor + 
							" want change currentTime to"+
							readyActor.activateTime + 
							" \nbut currentTime =" + currentTime
							);
					return;
				}
				// Змінюємо поточний час відповідно до
				// запланованого часу активації актора
				currentTime = readyActor.activateTime;
				fireChangeTimeEvent();
				printToProtocol(currentTime + " new Modeling time: ");
				readyActor.resume();
			} else {
				// If timingActorQueue isEmpty
				printToProtocol("Nothing will happen " 
						+ "in the model anymore");
				break;
			}
		}
		// Диспечер завершує роботу
		// Зільнюються актори, що чекають на виконання умов
		while (waitingActorQueue.size() > 0) {
			Actor a = waitingActorQueue.remove(0);
			a.resume();
		}
		printToProtocol("Dispatcher finished work");
		// Формування події DispatcherFinish
		fireDispatcherFinishEvent();
		starting = false;
		// Закриваємо файл протоколу
		if (out != null)
			try {
				out.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
	}

	/**
	 * Задание имени файла для вывода отладочного протокола работы модели. Имя
	 * "Console" обеспечивает вывод протокола на консоль
	 * 
	 * @param newProtocolFileName
	 */
	public void setProtocolFileName(java.lang.String newProtocolFileName) {
		protocolFileName = newProtocolFileName;
	}

	/**
	 * Метод вывода в протокол строки отладочной информации
	 * 
	 * @param newString
	 */

	public void printToProtocol(String newString) {

		if (protocolFileName == null || protocolFileName.trim().length() == 0) {
			return;
		}
		if (protocolFileName == "Console") {
			EventQueue.invokeLater(() -> getFrame().getTextArea().append(newString + '\n'));
			return;
		}
		try {
			getOut().write(newString);
			getOut().newLine();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	// ////////////////////////////////////////////////////////////////
	// Методы, обеспечивающие доступ к полям диспетчера

	/**
	 * Метод доступа к текущему модельному времени
	 * 
	 * @return double
	 */
	public double getCurrentTime() {
		return currentTime;
	}

	/**
	 * Доступ к потоку выполнения правил действия диспетчера
	 * 
	 * @return boolean
	 */
	public final Thread getThread() {
		return thread;
	}

	/**
	 * Доступ к упорядоченной очереди актеров, приостановленных на время
	 * 
	 * @return PriorityQueue
	 */
	public final Queue<Actor> getTimingActorQueue() {
		return timingActorQueue;
	}

	/**
	 * Доступ к очереди актеров, ждущих выполнения условия
	 * 
	 * @return Queue
	 */
	public final List<Actor> getWaitingActorQueue() {
		return waitingActorQueue;
	}

	// ////////////////////////////////////////////////////////////////
	// Методы, обеспечивающие формирование событий Диспетчера
	/**
	 * Add arr ChangeTimeListener to the listener list. The listener is registered
	 * for all properties.
	 * 
	 * @param listener TheChangeTimeListener to be added
	 */

	public synchronized void addChangeTimeListener(ChangeTimeListener listener) {
		if (changeTimeListeners == null) {
			changeTimeListeners = new java.util.Vector<ChangeTimeListener>();
		}
		changeTimeListeners.addElement(listener);
	}

	/**
	 * Add arr DispatcherFinishListener to the listener list. The listener is
	 * registered for all properties.
	 * 
	 * @param listener The DispatcherFinishListener to be added
	 */

	public synchronized void addDispatcherFinishListener(DispatcherFinishListener listener) {
		if (dispatcherFinishListeners == null) {
			dispatcherFinishListeners = new java.util.Vector<DispatcherFinishListener>();
		}
		dispatcherFinishListeners.addElement(listener);
	}

	/**
	 * Add arr DispatcherStartListener to the listener list. The listener is
	 * registered for all properties.
	 * 
	 * @param listener The DispatcherStartListener to be added
	 */

	public synchronized void addDispatcherStartListener(DispatcherStartListener listener) {
		if (dispatcherStartListeners == null) {
			dispatcherStartListeners = new java.util.Vector<DispatcherStartListener>();
		}
		dispatcherStartListeners.addElement(listener);
	}

	/**
	 * Fire an existing ChangeTimeEvent to any registered leafDeletedListeners.
	 * 
	 * @param evt The ChangeTimeEvent object.
	 */
	private void fireChangeTimeEvent() {
		Vector<ChangeTimeListener> targets = null;
		synchronized (this) {
			if (changeTimeListeners != null) {
				targets = (Vector<ChangeTimeListener>) changeTimeListeners.clone();
			}
		}
		if (targets != null) {
			for (int i = 0; i < targets.size(); i++) {
				ChangeTimeListener target = (ChangeTimeListener) targets.elementAt(i);
				target.onChangeTime(new EventObject(Dispatcher.this));
			}
		}

	}

	/**
	 * Fire an existing DispatcherFinishEvent to any registered
	 * dispatcherFinishListeners.
	 * 
	 * @param evt The DispatcherFinishEvent object.
	 */
	private void fireDispatcherFinishEvent() {
		java.util.Vector targets = null;
		synchronized (this) {
			if (dispatcherFinishListeners != null) {
				targets = (java.util.Vector) dispatcherFinishListeners.clone();
			}
		}
		if (targets != null) {
			for (int i = 0; i < targets.size(); i++) {
				DispatcherFinishListener target = (DispatcherFinishListener) targets.elementAt(i);
				target.onDispatcherFinish();
			}
		}

	}

	/**
	 * Fire an existing DispatcherStartEvent to any registered
	 * dispatcherStartListeners.
	 * 
	 * @param evt The DispatcherStartEvent object.
	 */
	private void fireDispatcherStartEvent() {
		java.util.Vector targets = null;
		synchronized (this) {
			if (dispatcherStartListeners != null) {
				targets = (java.util.Vector) dispatcherStartListeners.clone();
			}
		}
		if (targets != null) {
			for (int i = 0; i < targets.size(); i++) {
				DispatcherStartListener target = (DispatcherStartListener) targets.elementAt(i);
				target.onDispatcherStart();
			}
		}

	}

	/**
	 * Remove arr ChangeTimeListener from the listener list. This removes arr
	 * ChangeTimeListener that was registered for all properties.
	 * 
	 * @param listener The ChangeTimeListener to be removed
	 */

	public synchronized void removeChangeTimeListener(ChangeTimeListener listener) {
		if (changeTimeListeners == null) {
			return;
		}
		changeTimeListeners.removeElement(listener);
	}

	/**
	 * Remove arr DispatcherFinishListener from the listener list. This removes arr
	 * DispatcherFinishListener that was registered.
	 * 
	 * @param listener The DispatcherFinishListener to be removed
	 */

	public synchronized void removeDispatcherFinishListener(DispatcherFinishListener listener) {
		if (dispatcherFinishListeners == null) {
			return;
		}
		dispatcherFinishListeners.removeElement(listener);
	}

	/**
	 * Remove arr DispatcherStartListener from the listener list. This removes arr
	 * DispatcherStartListener that was registered.
	 * 
	 * @param listener The DispatcherStartListener to be removed
	 */

	public synchronized void removeDispatcherStartListener(DispatcherStartListener listener) {
		if (dispatcherStartListeners == null) {
			return;
		}
		dispatcherStartListeners.removeElement(listener);
	}

	private class Console extends JFrame {

		private JPanel contentPane;
		private JScrollPane scrollPane;
		private JTextArea textArea;
		private JPanel panel;
		private JLabel lblFontSize;
		private JSpinner spinner;

		/**
		 * Create the frame.
		 */
		public Console() {
			setTitle("Model activity protocol");
			setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
			try {
				UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
			} catch (Exception e) {
				e.printStackTrace();
			}
			setBounds(100, 100, 450, 300);
			contentPane = new JPanel();
			contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
			setContentPane(contentPane);
			contentPane.setLayout(new GridLayout(1, 0, 0, 0));
			contentPane.add(getScrollPane());
		}

		public JScrollPane getScrollPane() {
			if (scrollPane == null) {
				scrollPane = new JScrollPane();
				scrollPane.setViewportView(getTextArea());
				scrollPane.setColumnHeaderView(getPanel());
			}
			return scrollPane;
		}

		public JTextArea getTextArea() {
			if (textArea == null) {
				textArea = new JTextArea();
				textArea.setMargin(new Insets(2, 5, 2, 2));
				textArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
			}
			return textArea;
		}

		public JLabel getLblFontSize() {
			if (lblFontSize == null) {
				lblFontSize = new JLabel("Font size");
			}
			return lblFontSize;
		}

		public JSpinner getSpinner() {
			if (spinner == null) {
				spinner = new JSpinner();
				spinner.addChangeListener(new ChangeListener() {
					public void stateChanged(ChangeEvent e) {
						stateChangedSpinner(e);
					}
				});

				spinner.setModel(new SpinnerNumberModel(12, 10, 24, 2));
			}
			return spinner;
		}

		protected void stateChangedSpinner(ChangeEvent e) {
			int size = (int) spinner.getValue();
			Font font = new Font(Font.MONOSPACED, Font.PLAIN, size);
			textArea.setFont(font);
			textArea.setText(textArea.getText());
		}

		public JPanel getPanel() {
			if (panel == null) {
				panel = new JPanel();
				panel.add(getLblFontSize());
				panel.add(getSpinner());
			}
			return panel;
		}

	}

	public BufferedWriter getOut() {
		if (out == null) {
			try {
				out = new BufferedWriter(new FileWriter(protocolFileName, false));
			} catch (Exception e) {
				System.out.println("Error open protocol file");
			}
		}
		return out;
	}

	public Console getFrame() {
		if (frame == null) {
			frame = new Console();
			frame.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
			frame.setVisible(true);
		}
		return frame;
	}
}
