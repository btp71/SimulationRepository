package widgets.experiments;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Queue;
import java.util.TreeMap;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ConcurrentSkipListMap;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.border.LineBorder;
import javax.swing.event.CaretEvent;
import javax.swing.event.CaretListener;

import process.Dispatcher;
import process.DispatcherFinishListener;
import process.IModelFactory;
import widgets.ChooseData;
import widgets.ChooseDataH;
import widgets.Diagram;
import widgets.regres.RegresAnaliserView;

public class ExperimentManager extends JPanel {
	private JCheckBox jCheckBox;
	private JButton jButtonRedraw;
	private Diagram diagram;
	private RegresAnaliserView regresAnaliser;
	private ChooseData chooseDataFactors;
	private JButton jButtonStart;
	private ChooseDataH chooseDataRepeat;
	private int count; // countOfExperimentsOnLevel
	private double[] factors;
	private Map<String, Map<Double, Queue<Double>>> allResultsMap;
	private IModelFactory factory = null;
	private volatile String[] keyStrings;
	private DefaultComboBoxModel<String> comboModel;
	private CountDownLatch createMapCDL;
	private JComboBox<String> comboBox;
	private Executor pool = Executors.newWorkStealingPool();

	/**
	 * Create the panel.
	 */
	public ExperimentManager() {
		setBorder(new LineBorder(new Color(0, 0, 0)));
		GridBagLayout gridBagLayout = new GridBagLayout();
		gridBagLayout.columnWidths = new int[] { 0, 0, 180, 50, 0 };
		gridBagLayout.rowHeights = new int[] { 0, 25, 25, 30, 0 };
		gridBagLayout.columnWeights = new double[] { 1.0, 1.0, 0.0, 0.0,
				Double.MIN_VALUE };
		gridBagLayout.rowWeights = new double[] { 1.0, 0.0, 0.0, 0.0,
				Double.MIN_VALUE };
		setLayout(gridBagLayout);

		diagram = new Diagram();
		diagram.setTitleText("The results of the experiment");
		GridBagConstraints gbc_diagram = new GridBagConstraints();
		gbc_diagram.gridwidth = 2;
		gbc_diagram.insets = new Insets(5, 5, 5, 5);
		gbc_diagram.fill = GridBagConstraints.BOTH;
		gbc_diagram.gridx = 0;
		gbc_diagram.gridy = 0;
		add(diagram, gbc_diagram);

		regresAnaliser = new RegresAnaliserView();
		regresAnaliser.setDiagram(diagram);
		GridBagConstraints gbc_regresAnaliser = new GridBagConstraints();
		gbc_regresAnaliser.gridwidth = 2;
		gbc_regresAnaliser.insets = new Insets(5, 5, 5, 5);
		gbc_regresAnaliser.fill = GridBagConstraints.BOTH;
		gbc_regresAnaliser.gridx = 2;
		gbc_regresAnaliser.gridy = 0;
		add(regresAnaliser, gbc_regresAnaliser);

		JLabel lblSelectionOfExperiment = new JLabel();
		lblSelectionOfExperiment.setText("Selection of experiment results");
		lblSelectionOfExperiment.setName("factorLabel");
		lblSelectionOfExperiment.setHorizontalTextPosition(SwingConstants.CENTER);
		lblSelectionOfExperiment.setHorizontalAlignment(SwingConstants.CENTER);
		lblSelectionOfExperiment.setFont(new Font("Dialog", Font.PLAIN, 12));
		GridBagConstraints gbc_lblSelectionOfExperiment = new GridBagConstraints();
		gbc_lblSelectionOfExperiment.gridwidth = 2;
		gbc_lblSelectionOfExperiment.insets = new Insets(5, 5, 0, 5);
		gbc_lblSelectionOfExperiment.gridx = 0;
		gbc_lblSelectionOfExperiment.gridy = 1;
		add(lblSelectionOfExperiment, gbc_lblSelectionOfExperiment);

		chooseDataFactors = new ChooseData();
		chooseDataFactors.setText("0.5  0.6  0.7  0.8");
		chooseDataFactors
		.setTitle("Factor values");
		chooseDataFactors.addCaretListener(new CaretListener() {
			public void caretUpdate(CaretEvent e) {
				onFactorChange();
			}
		});
		GridBagConstraints gbc_chooseDataFactors = new GridBagConstraints();
		gbc_chooseDataFactors.gridwidth = 2;
		gbc_chooseDataFactors.gridheight = 2;
		gbc_chooseDataFactors.insets = new Insets(5, 5, 5, 5);
		gbc_chooseDataFactors.fill = GridBagConstraints.HORIZONTAL;
		gbc_chooseDataFactors.gridx = 2;
		gbc_chooseDataFactors.gridy = 1;
		add(chooseDataFactors, gbc_chooseDataFactors);

		comboBox = new JComboBox<>();
		comboBox.setPreferredSize(new Dimension(228, 20));
		comboBox.setMinimumSize(new Dimension(228, 20));
		comboBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				onComboChange(e);
			}
		});

		GridBagConstraints gbc_comboBox = new GridBagConstraints();
		gbc_comboBox.gridwidth = 2;
		gbc_comboBox.insets = new Insets(0, 5, 5, 5);
		gbc_comboBox.gridx = 0;
		gbc_comboBox.gridy = 2;
		add(comboBox, gbc_comboBox);

		jCheckBox = new JCheckBox("Ln");
		GridBagConstraints gbc_jCheckBox = new GridBagConstraints();
		gbc_jCheckBox.insets = new Insets(0, 0, 0, 5);
		gbc_jCheckBox.gridx = 0;
		gbc_jCheckBox.gridy = 3;
		add(jCheckBox, gbc_jCheckBox);

		jButtonRedraw = new JButton("Redraw results");
		jButtonRedraw.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent e) {
				redraw(getDiagram());
			}
		});

		GridBagConstraints gbc_jButtonRedraw = new GridBagConstraints();
		gbc_jButtonRedraw.insets = new Insets(5, 5, 5, 5);
		gbc_jButtonRedraw.gridx = 1;
		gbc_jButtonRedraw.gridy = 3;
		add(jButtonRedraw, gbc_jButtonRedraw);

		chooseDataRepeat = new ChooseDataH();
		chooseDataRepeat.setText("  5   ");
		chooseDataRepeat.setDividerLocation(0.7);
		chooseDataRepeat
		.setTitle("Repeat at level");
		GridBagConstraints gbc_chooseDataRepeat = new GridBagConstraints();
		gbc_chooseDataRepeat.insets = new Insets(5, 5, 5, 5);
		gbc_chooseDataRepeat.fill = GridBagConstraints.HORIZONTAL;
		gbc_chooseDataRepeat.gridx = 2;
		gbc_chooseDataRepeat.gridy = 3;
		add(chooseDataRepeat, gbc_chooseDataRepeat);

		jButtonStart = new JButton("Start");
		Runnable r = () -> onBtnStart();
		jButtonStart.addActionListener((e) -> new Thread(r).start());
		GridBagConstraints gbc_jButtonStart = new GridBagConstraints();
		gbc_jButtonStart.insets = new Insets(5, 5, 5, 5);
		gbc_jButtonStart.gridx = 3;
		gbc_jButtonStart.gridy = 3;
		add(jButtonStart, gbc_jButtonStart);

	}

	public void onBtnStart() {
		getJButtonStart().setEnabled(false);
		onFactorChange();
		// Читаємо параметри експерименту
		count = getChooseDataRepeat().getInt();
		factors = getChooseDataFactors().getDoubleArray();
		// Бар'єр для відновлення Enabled кнопки Старт
		CountDownLatch doneCDL = new CountDownLatch(factors.length * count);
		// Створюємо карту для результатів
		allResultsMap = new ConcurrentSkipListMap<>();
		createMapCDL = new CountDownLatch(1);

		// Готуємо діаграму
		if (getDiagram() != null) {
			getDiagram().getPainter().setColor(new Color(0, 0, 255));
			getDiagram().clear();
		}

		// Клас, що містить завдання для потоків, що проводять експерименти
		// //////////////////////////////////////////
		class Task implements Runnable {
			private double factor;

			public Task(double factor) {
				this.factor = factor;
			}

			@Override
			public void run() {
				Dispatcher dispatcher = new Dispatcher();
				IExperimentable model = (IExperimentable) (getFactory()
						.createModel(dispatcher));
				// Ініціалізація моделі
				model.initForExperiment(factor);
				// Handler for DispatcherFinishEvent
				DispatcherFinishListener df = new Df(model, factor, doneCDL);

				dispatcher.addDispatcherFinishListener(df);
				// Починаємо експеримент з моделлю
				dispatcher.start();
			}
		}
		// Цикл повторів для одного значення фактору
		for (int k = 0; k < count; k++) {
			// Цикл експериментів для різних значень фактору
			for (int j = 0; j < factors.length; j++) {
				// Запуск експерименту
				pool.execute(new Task(factors[j]));
			}
		}
		try {
			doneCDL.await();
		} catch (InterruptedException e) {
			System.out.println("terminated after 1 MINUTES");
		}
		// New create place of comboModel after doneCDL.await();
		//10/05/2015
		// *********************************************

//		keyStrings = (String[]) allResultsMap.keySet().toArray(
//				new String[allResultsMap.keySet().size()]);

		// Create model for combox  using order that was in
		// getResultOfExperiment() method	04/05/22
		IExperimentable tmpModel =(IExperimentable) factory.
				createModel(new Dispatcher());
		keyStrings = (String[]) tmpModel.getResultOfExperiment().keySet()
				.toArray(new String[allResultsMap.keySet().size()]);
		comboModel = new DefaultComboBoxModel<>(keyStrings);
		comboBox.setModel(comboModel);
		// **************************************************
		getJButtonStart().setEnabled(true);
		Map<Double,List<Double>> dataMap = getResultMap();
		getRegresAnaliser().setDataMap(dataMap);
		redraw(diagram);
	}

	// TODO "Double-Checked Locking" idiom 11/05/15
	private void createKeyStrings(Map<String, Double> resMap) {
		String[] result = keyStrings;
		if (result == null) {
			synchronized (this) {
				result = keyStrings;
				if (result == null) {
					keyStrings = result = (String[]) resMap.keySet().toArray(
							new String[resMap.keySet().size()]);
				}
			}
		}
	}

	// TODO ?add synchronized 8.05.2015
	private synchronized void initResultMap() {
		if (allResultsMap.isEmpty())
			for (String keyStr : keyStrings) {
				Map<Double, Queue<Double>> subMap = new ConcurrentHashMap<>();
				for (double f : factors)
					subMap.put(f, new ConcurrentLinkedQueue<Double>());
				allResultsMap.put(keyStr, subMap);
			}
		createMapCDL.countDown();
	}

	public void redraw(Diagram diagram) {
		if (diagram == null)
			return;

		// Search for max vertical value
		double max = Double.MIN_VALUE;
		for (Double factor : getResultMap().keySet()) {
			List<Double> resultList = getResultMap().get(factor);
			for (Double result : resultList) {
				if(result > max)
					max = result;
			}
		}
		if(max == Double.MIN_VALUE)
			return;
		double k = 1;
		while(max*k < 1) k *= 10;
		while(max*k >= 10) k/=10;
		double n = k*max;
		double[][] bounds = {
				{1.5, 2, 4, 5, 7.5, 8, 10},
				  {5, 4, 4, 5,  5,  4, 5} };
		int i = 0;
		while(n > bounds[0][i]) i++;
		max = bounds[0][i] / k;
		String maxY;
		if(max <10)
			maxY = String.format(Locale.ROOT,"%1.2f", max);
		else
			maxY = String.format(Locale.ROOT,"%d", (int)max);
		diagram.setVerticalMaxText(maxY);
		diagram.setGridByY((int)bounds[1][i]);

		diagram.getPainter().setColor(new Color(0, 0, 255));
		diagram.clear();
		for (Double factor : getResultMap().keySet()) {
			List<Double> resultList = getResultMap().get(factor);
			for (Double result : resultList) {
				diagram.getPainter().drawOvalAtXY(factor.floatValue(),
						result.floatValue(), 4, 4);
			}
		}
	}

	private void onComboChange(ActionEvent e) {
		getRegresAnaliser().setDataMap(getResultMap());
		redraw(getDiagram());

	}

	public IModelFactory getFactory() {
		if (factory == null)
			System.out.println("Не визначено factory для ExperimentControl");
		return factory;
	}

	public void setFactory(IModelFactory factory) {
		this.factory = factory;
	}


	public Map<Double, List<Double>> getResultMap() {
		Map<Double, List<Double>> returnMap = new TreeMap<>();
		String keyStr = (String) comboBox.getSelectedItem();
		if (keyStr != null) {
			Map<Double, Queue<Double>> subMap = allResultsMap.get(keyStr);

			for (double f : factors) {
				ArrayList<Double> arr = new ArrayList<>(count);
				for (Double y : subMap.get(f)) {
					if (getJCheckBox().isSelected())
						arr.add(Math.log(y));
					else
						arr.add(y);
				}
				returnMap.put(f, arr);
			}
		}
		return returnMap;
	}

	public JCheckBox getJCheckBox() {
		return jCheckBox;
	}

	public JButton getJButtonRedraw() {
		return jButtonRedraw;
	}

	public Diagram getDiagram() {
		return diagram;
	}

	public RegresAnaliserView getRegresAnaliser() {
		return regresAnaliser;
	}

	public ChooseData getChooseDataFactors() {
		return chooseDataFactors;
	}

	public JButton getJButtonStart() {
		return jButtonStart;
	}

	public ChooseDataH getChooseDataRepeat() {
		return chooseDataRepeat;
	}

	public JComboBox<String> getComboBox() {
		return comboBox;
	}

	private void onFactorChange() {
		try {
			double[] ar = chooseDataFactors.getDoubleArray();
			Arrays.sort(ar);
			double[] minMaxGrid = calcMinMax(ar);

			String minX;
			if(minMaxGrid[0] < 1)
				minX = String.format(Locale.ROOT,"%1.2f", minMaxGrid[0]);
			else
				minX = String.format(Locale.ROOT,"%1.1f",minMaxGrid[0]);
			diagram.setHorizontalMinText(minX);
			String maxX;
			if(minMaxGrid[1] < 1)
				maxX = String.format(Locale.ROOT,"%1.2f", minMaxGrid[1]);
			else
				maxX = String.format(Locale.ROOT,"%1.1f",minMaxGrid[1]);
			diagram.setHorizontalMaxText(maxX);
			diagram.setGridByX((int)minMaxGrid[2]);

		} catch (Exception e2) {

		}
	}


	private double[] calcMinMax(double[] ar) {

		double minH = ar[0];
		double maxH = ar[ar.length - 1];
		double dH = 9999999;
		Double pred = null;
		for(Double d :ar) {
			if( pred !=null && !d.equals(pred) && d - pred < dH)
				 dH = d - pred;
			pred = d;
		}
		minH -= dH;
		maxH += dH;
		int gridX = (int)((maxH - minH) / dH + 0.5);
		maxH = minH + dH*gridX;
		double[] res = {minH, maxH, gridX};
		return res;
	}

	private class Df implements DispatcherFinishListener {

		private IExperimentable model;
		private double factor;
		private CountDownLatch doneCDL;
		public Df(IExperimentable model, 
				double factor, CountDownLatch doneCDL) {
			this.model = model;
			this.factor = factor;
			this.doneCDL = doneCDL;
		}

		@Override
		public void onDispatcherFinish() {
			try {
				// Отримуємо мапу "Назва відгуку" => "Значення відгуку"
				Map<String, Double> resMap = model.getResultOfExperiment();
				// Якщо це перший результат, створюємо модель комбо
				// та мапу для усіх результатів
				if (keyStrings == null)
					createKeyStrings(resMap);
				if (allResultsMap.isEmpty())
					initResultMap();
				try {
					createMapCDL.await();
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				// Розносимо результати по мапі усіх результатів
				int i = 0;
				//for (String keyStr : allResultsMap.keySet()) {
				for (String keyStr : keyStrings) {
					Double y = resMap.get(keyStr);
					allResultsMap.get(keyStr).get(factor).add(y);
					if (getJCheckBox().isSelected())
						y = Math.log(y);
					if (i == 0)
						getDiagram().getPainter().drawOvalAtXY((float) factor,
								y.floatValue(), 4, 4);
					i++;

				}
				doneCDL.countDown();

			} catch (Exception e1) {
				System.out.println(Arrays.toString(keyStrings));
				e1.printStackTrace();
			}

		}

	}
}
