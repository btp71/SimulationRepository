package widgets.regres;

import java.util.LinkedList;
import java.util.List;
import java.util.function.Function;

import finder.FinderAsSumKfunc;


	public class Regres3Parabola extends FinderAsSumKfunc  {
		@Override
		public List<Function<Double, Double>> functionList() {
			List<Function<Double, Double>> list = new LinkedList<>();
			list.add((x)-> x*x);
			list.add((x)-> x);
			list.add((x)-> 1.0);
			return list;
		}
	public String getLabel() {
		return "q=a1*x*x+a2*x +a3";
	}

}
