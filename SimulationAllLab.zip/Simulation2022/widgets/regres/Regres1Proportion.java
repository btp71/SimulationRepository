package widgets.regres;

import java.util.LinkedList;
import java.util.List;
import java.util.function.Function;

import finder.FinderAsSumKfunc;


/**
 * @author sanbok
 */
	public class Regres1Proportion extends FinderAsSumKfunc  {
		@Override
		public List<Function<Double, Double>> functionList() {
			List<Function<Double, Double>> list = new LinkedList<>();
			list.add((x)-> x);
			return list;
		}
	/*
	 * (non-Javadoc)
	 * 
	 * @see simulationRegress.Tester#getLabelName()
	 */
	public String getLabel() {
		return "q=a1*x";
	}
}
