package widgets.regres;

import java.util.LinkedList;
import java.util.List;
import java.util.function.Function;

import finder.FinderAsSumKfunc;



	public class Regres1Giperbola extends FinderAsSumKfunc  {
		@Override
		public List<Function<Double, Double>> functionList() {
			List<Function<Double, Double>> list = new LinkedList<>();
			list.add((x)->1/x);
			return list;
		}
	public String getLabel() {
		return "q=a1/x";
	}

}
