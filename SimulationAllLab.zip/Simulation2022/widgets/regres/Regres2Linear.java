package widgets.regres;

import java.util.LinkedList;
import java.util.List;
import java.util.function.Function;

import finder.FinderAsSumKfunc;

public class Regres2Linear extends FinderAsSumKfunc{
	
	//Метод повертає список елементарних складових ф-ї регресії 
	@Override
	public List<Function<Double, Double>> functionList() {
		List<Function<Double, Double>> list = new LinkedList<>();
		list.add((x)-> x);
		list.add((x)-> 1.0);
		return list;
	}

	@Override
	public String toString() {
		return "q=a1*x + a2";
	}
}
