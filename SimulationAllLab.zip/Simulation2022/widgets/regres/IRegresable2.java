package widgets.regres;

import java.util.List;
import java.util.Map;

public interface IRegresable2 {
	public Map<Double, List<Double>> getResultMap() ;

}
