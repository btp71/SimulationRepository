package widgets.regres;

import java.util.LinkedList;
import java.util.List;
import java.util.function.Function;

import finder.FinderAsSumKfunc;


public class Regres1Sqrt extends FinderAsSumKfunc  {

	@Override
	public List<Function<Double, Double>> functionList() {
		List<Function<Double, Double>> list = new LinkedList<>();
		list.add((x)-> Math.sqrt(x));
		return list;
	}

	public String getLabel() {
		return "q=a1*sqrt(x)";
	}

}
