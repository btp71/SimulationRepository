package widgets.regres;

import java.util.LinkedList;
import java.util.List;
import java.util.function.Function;

import finder.FinderAsSumKfunc;

public class Regres2Giperbola extends FinderAsSumKfunc {

	public List<Function<Double, Double>> functionList() {
		List<Function<Double, Double>> list = new LinkedList<>();
		list.add((x)->1/x);
		list.add((x)->1.0);
		return list;
	}
	
	public String getLabel() {
		return "y=a1/x + a2";
	}

	@Override
	public String toString() {
		return getLabel() ;
	}
	
}
