package widgets.trans;

import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EtchedBorder;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;

import finder.IFinderRegresParm;
import process.Dispatcher;
import process.IModelFactory;
import widgets.Diagram;
import widgets.Painter;
import widgets.regres.RgrsProcDelyCdGr;
import widgets.regres.RgrsProcExpCd;
import widgets.regres.RgrsProcExpGr;
import widgets.regres.RgrsProcOverExpCd;

/**
 * Объекты этого класса предназначены для задания параметров мониторинга,
 * создания и запуска требуемого количества параллельно работающих моделей и
 * периодического снятия и усреднения данных о работе модели. Создание моделей,
 * их запуск и мониторинг осуществляется объектом monitor, который создается с
 * помощью безымянного внутреннего класса, наследующего класс Actor. Объект
 * monitor создается вместе с диспетчером при нажатии на кнопку "Старт". Объект
 * monitor передается диспетчеру, после чего диспетчер запускается. После
 * запуска диспетчера начинают выполняться правила действия монитора. Монитор
 * создает массив объектов ITransProcesable, используя объект model тако же
 * типа, вызывая его метод createAndInitTransModel(Dispatcherdispatcher,double
 * finishTime), который должен обеспечить создание и подготовку модели к работе.
 * Работать модель должна с тем же диспетчером, что и монитор. Созданные модели
 * монитор передает в стартовый список диспетчера с помощью метода
 * componentsToStartList(). Мониторинг параллельно работающих моделей
 * осуществляется через промежутки interval модельного времени. В начале каждого
 * промежутка накопители информации в модели инициализируются с помощью метода
 * resetAccum(). В конце промежутка времени interval, monitor, с помощью метода
 * getTransResult(), опрашивает все параллельно работающие модели. Результаты
 * опроса усредняются, передаются объекту painter для отрисовки на диаграмме и
 * запомонаются в массиве intervalAverageArray.
 * 
 * Creation date: (18.11.2007 17:26:58)
 * 
 * @author: biv
 */
public class TransProcessManager extends javax.swing.JPanel {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private double interval; // Интервал усреднения информации о процессе

	private int nIntervals; // Число интервалов усреднения

	private int nParallel; // Число параллельно работающих моделей

	private IModelFactory factory = null;

	private TransMonitor monitor = null;

	private Dispatcher dispatcher = null;

	private JButton jButtonStart = null;

	private JPanel jPanelIntrval = null;

	private JTextField jTextFieldInterval = null;

	private JPanel jPanelNintervals = null;

	private JTextField jTextFieldNintervals = null;

	private JPanel jPanelNparallel = null;

	private JTextField jTextFieldNParallel = null;
	private JLabel lblMonitorParameters;
	private Diagram diagram;
	private JComboBox<String> comboBoxQueue;
	private JComboBox<IFinderRegresParm> comboBoxRegres;

	private DefaultComboBoxModel<IFinderRegresParm> comboRegresModel;

	/**
	 * This is the default constructor
	 */
	public TransProcessManager() {
		super();
		
		initialize();
	}

	/**
	 * Initialize the class.
	 */
	private void initialize() {
		try {
			setName("TransProcessManager");
			setBorder(new LineBorder(new Color(0, 0, 0)));
			setSize(427, 253);
			this.setNumberOfModel("200");
			this.setNumberOfInterval("5");
			this.setTextInterval("15");
			GridBagLayout gridBagLayout = new GridBagLayout();
			gridBagLayout.columnWidths = new int[] { 102, 0, 0 };
			gridBagLayout.rowHeights = new int[] { 13, 54, 54, 54, 0, 26, 0 };
			gridBagLayout.columnWeights = new double[] { 0.0, 1.0, Double.MIN_VALUE };
			gridBagLayout.rowWeights = new double[] { 0.0, 1.0, 1.0, 1.0, 0.0, 0.0, Double.MIN_VALUE };
			setLayout(gridBagLayout);
			GridBagConstraints gbc_lblMonitorParameters = new GridBagConstraints();
			gbc_lblMonitorParameters.fill = GridBagConstraints.VERTICAL;
			gbc_lblMonitorParameters.insets = new Insets(5, 5, 5, 5);
			gbc_lblMonitorParameters.gridx = 0;
			gbc_lblMonitorParameters.gridy = 0;
			add(getLblMonitorParameters(), gbc_lblMonitorParameters);
			GridBagConstraints gbc_jPanelIntrval = new GridBagConstraints();
			gbc_jPanelIntrval.insets = new Insets(0, 0, 5, 5);
			gbc_jPanelIntrval.gridx = 0;
			gbc_jPanelIntrval.gridy = 1;
			this.add(getJPanelIntrval(), gbc_jPanelIntrval);
			GridBagConstraints gbc_diagram_1 = new GridBagConstraints();
			gbc_diagram_1.gridheight = 5;
			gbc_diagram_1.insets = new Insets(5, 5, 5, 0);
			gbc_diagram_1.fill = GridBagConstraints.BOTH;
			gbc_diagram_1.gridx = 1;
			gbc_diagram_1.gridy = 0;
			add(getDiagram(), gbc_diagram_1);
			GridBagConstraints gbc_jPanelNintervals = new GridBagConstraints();
			gbc_jPanelNintervals.insets = new Insets(0, 0, 5, 5);
			gbc_jPanelNintervals.gridx = 0;
			gbc_jPanelNintervals.gridy = 2;
			this.add(getJPanelNintervals(), gbc_jPanelNintervals);
			GridBagConstraints gbc_jPanelNparallel = new GridBagConstraints();
			gbc_jPanelNparallel.insets = new Insets(0, 0, 5, 5);
			gbc_jPanelNparallel.gridx = 0;
			gbc_jPanelNparallel.gridy = 3;
			this.add(getJPanelNparallel(), gbc_jPanelNparallel);
			GridBagConstraints gbc_jButtonStart = new GridBagConstraints();
			gbc_jButtonStart.insets = new Insets(5, 5, 5, 5);
			gbc_jButtonStart.gridx = 0;
			gbc_jButtonStart.gridy = 4;
			this.add(getJButtonStart(), gbc_jButtonStart);
			GridBagConstraints gbc_comboBoxRegres = new GridBagConstraints();
			gbc_comboBoxRegres.insets = new Insets(0, 0, 0, 5);
			gbc_comboBoxRegres.gridx = 0;
			gbc_comboBoxRegres.gridy = 5;
			add(getComboBoxRegres(), gbc_comboBoxRegres);
			GridBagConstraints gbc_comboBoxQueue = new GridBagConstraints();
			gbc_comboBoxQueue.insets = new Insets(5, 5, 0, 0);
			gbc_comboBoxQueue.fill = GridBagConstraints.HORIZONTAL;
			gbc_comboBoxQueue.gridx = 1;
			gbc_comboBoxQueue.gridy = 5;
			add(getComboBoxQueue(), gbc_comboBoxQueue);
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}

	/**
	 * This method initializes jButtonStart
	 * 
	 * @return javax.swing.JButton
	 */
	private JButton getJButtonStart() {
		if (jButtonStart == null) {
			jButtonStart = new JButton();
			jButtonStart.setText("Start");
			jButtonStart.setMinimumSize(new Dimension(100, 22));
			jButtonStart.setHorizontalTextPosition(SwingConstants.CENTER);
			jButtonStart.setMaximumSize(new Dimension(11111, 2222222));
			jButtonStart.setPreferredSize(new Dimension(196, 560));
			jButtonStart.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					startMonitoring();
				}
			});
		}
		return jButtonStart;
	}

	// Запуск процеса моделюванння
	private void startMonitoring() {

		getJButtonStart().setEnabled(false);
		getComboBoxRegres().setEnabled(false);
		diagram.setHorizontalMaxText(String.valueOf((int) getFinishTime()));
		diagram.setGridByX(getNIntervals());
		diagram.clear();
		monitor = new TransMonitor();
		monitor.setNameForProtocol("Monitor");
		monitor.setDiagram(getDiagram());
		monitor.setComboBox(getComboBoxQueue());
		monitor.setNParallel(getNParallel());
		monitor.setNIntervals(getNIntervals());
		monitor.setInterval(getInterval());
		monitor.setFactory(getFactory());
		dispatcher = new Dispatcher();
		
		dispatcher.addDispatcherFinishListener(() -> {
			getJButtonStart().setEnabled(true);
			onComboQueueAction();
			getComboBoxRegres().setEnabled(true);
		});

		dispatcher.addStartingActor(getMonitor());
		dispatcher.start();

	}

	/*
	 * Возвращает время моделирования
	 */
	public double getFinishTime() {
		return getInterval() * getNIntervals();
	}

	private JPanel getJPanelIntrval() {
		if (jPanelIntrval == null) {
			jPanelIntrval = new JPanel();
			jPanelIntrval.setLayout(new CardLayout());
			jPanelIntrval.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Averaging interval",
					javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION,
					new java.awt.Font("Dialog", java.awt.Font.PLAIN, 12), new java.awt.Color(51, 51, 51)));
			jPanelIntrval.setPreferredSize(new java.awt.Dimension(148, 47));
			jPanelIntrval.setMinimumSize(new java.awt.Dimension(148, 46));
			jPanelIntrval.add(getJTextFieldInterval(), getJTextFieldInterval().getName());
		}
		return jPanelIntrval;
	}

	/**
	 * This method initializes jTextFieldInterval
	 * 
	 * @return javax.swing.JTextField
	 */
	private JTextField getJTextFieldInterval() {
		if (jTextFieldInterval == null) {
			jTextFieldInterval = new JTextField();
			jTextFieldInterval.setName("jTextFieldInterval");
			jTextFieldInterval.setHorizontalAlignment(javax.swing.JTextField.CENTER);
			jTextFieldInterval.setText("15");
		}
		return jTextFieldInterval;
	}

	/**
	 * This method initializes jPanelNintervals
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getJPanelNintervals() {
		if (jPanelNintervals == null) {
			jPanelNintervals = new JPanel();
			jPanelNintervals.setLayout(new CardLayout());
			jPanelNintervals.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Number of intervals",
					javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.DEFAULT_POSITION,
					new java.awt.Font("Dialog", java.awt.Font.PLAIN, 12), new java.awt.Color(51, 51, 51)));
			jPanelNintervals.setPreferredSize(new java.awt.Dimension(148, 47));
			jPanelNintervals.setMinimumSize(new java.awt.Dimension(148, 46));
			jPanelNintervals.add(getJTextFieldNintervals(), getJTextFieldNintervals().getName());
		}
		return jPanelNintervals;
	}

	/**
	 * This method initializes jTextFieldNintervals
	 * 
	 * @return javax.swing.JTextField
	 */
	private JTextField getJTextFieldNintervals() {
		if (jTextFieldNintervals == null) {
			jTextFieldNintervals = new JTextField();
			jTextFieldNintervals.setName("jTextFieldNintervals");
			jTextFieldNintervals.setHorizontalAlignment(javax.swing.JTextField.CENTER);
			jTextFieldNintervals.setText("5");
		}
		return jTextFieldNintervals;
	}

	/**
	 * This method initializes jPanelParallel
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getJPanelNparallel() {
		if (jPanelNparallel == null) {
			jPanelNparallel = new JPanel();
			jPanelNparallel.setLayout(new CardLayout());
			jPanelNparallel.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Number of models",
					javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.DEFAULT_POSITION,
					new java.awt.Font("Dialog", java.awt.Font.PLAIN, 12), new java.awt.Color(51, 51, 51)));
			jPanelNparallel.setPreferredSize(new java.awt.Dimension(148, 47));
			jPanelNparallel.setMinimumSize(new java.awt.Dimension(148, 46));
			jPanelNparallel.add(getJTextFieldNparallel(), getJTextFieldNparallel().getName());
		}
		return jPanelNparallel;
	}

	/**
	 * This method initializes jTextFieldParallel
	 * 
	 * @return javax.swing.JTextField
	 */
	private JTextField getJTextFieldNparallel() {
		if (jTextFieldNParallel == null) {
			jTextFieldNParallel = new JTextField();
			jTextFieldNParallel.setName("jTextFieldNParallel");
			jTextFieldNParallel.setHorizontalAlignment(javax.swing.JTextField.CENTER);
			jTextFieldNParallel.setText("200");
		}
		return jTextFieldNParallel;
	}

	/**
	 * Method generated to support the promotion of the JTextFieldNparallelText
	 * attribute.
	 * 
	 * @return java.lang.String
	 */
	public java.lang.String getNumberOfModel() {
		return getJTextFieldNparallel().getText();
	}

	/**
	 * Method generated to support the promotion of the JTextFieldIntervalText
	 * attribute.
	 * 
	 * @return java.lang.String
	 */
	public java.lang.String getTextInterval() {
		return getJTextFieldInterval().getText();
	}

	/**
	 * Method generated to support the promotion of the JTextFieldNintervalsText
	 * attribute.
	 * 
	 * @return java.lang.String
	 */
	public java.lang.String getNumberOfInterval() {
		return getJTextFieldNintervals().getText();
	}

	/**
	 * Method generated to support the promotion of the JTextFieldNparallelText
	 * attribute.
	 * 
	 * @param arg1 java.lang.String
	 */
	public void setNumberOfModel(java.lang.String arg1) {
		getJTextFieldNparallel().setText(arg1);
	}

	/**
	 * Method generated to support the promotion of the JTextFieldIntervalText
	 * attribute.
	 * 
	 * @param arg1 java.lang.String
	 */
	public void setTextInterval(java.lang.String arg1) {
		getJTextFieldInterval().setText(arg1);
	}

	/**
	 * Method generated to support the promotion of the JTextFieldNintervalsText
	 * attribute.
	 * 
	 * @param arg1 java.lang.String
	 */
	public void setNumberOfInterval(java.lang.String arg1) {
		getJTextFieldNintervals().setText(arg1);
	}

	/**
	 * Called whenever the part throws an exception.
	 * 
	 * @param exception java.lang.Throwable
	 */
	private void handleException(java.lang.Throwable exception) {

		/* Uncomment the following lines to print uncaught exceptions to stdout */
		System.out.println("Не прошла инициализация визуальной части монитра");
		exception.printStackTrace(System.out);
	}

	public double getInterval() {
		return interval = Integer.parseInt(getJTextFieldInterval().getText());
	}

	public int getNIntervals() {
		return nIntervals = Integer.parseInt(getJTextFieldNintervals().getText());
	}

	public int getNParallel() {
		nParallel = Integer.parseInt(getJTextFieldNparallel().getText());
		return nParallel;
	}

	private IModelFactory getFactory() {
		if (factory == null)
			System.out.println("Не виначено factory для TransProcessManager");
		return factory;
	}

	public void setFactory(IModelFactory factory) {
		this.factory = factory;
	}

	public TransMonitor getMonitor() {
		return monitor;
	}



	public Map<Double, List<Double>> getResultMap() {
		HashMap<Double, List<Double>> resMap = new HashMap<>();
		for (int i = 0; i < nIntervals; i++) {
			double key = (i + 0.5) * interval;
			ArrayList<Double> resList = new ArrayList<>(1);
			resList.add(getMonitor().getAverageArray()[i]);
			resMap.put(key, resList);
		}
		return resMap;
	}

	private JLabel getLblMonitorParameters() {
		if (lblMonitorParameters == null) {
			lblMonitorParameters = new JLabel(
					"Monitor parameters");
			lblMonitorParameters.setPreferredSize(new Dimension(102, 20));
			lblMonitorParameters.setFont(new Font("Tahoma", Font.PLAIN, 12));
			lblMonitorParameters.setHorizontalAlignment(SwingConstants.CENTER);
		}
		return lblMonitorParameters;
	}

	public Diagram getDiagram() {
		if (diagram == null) {
			diagram = new Diagram();
			diagram.setTitleText(
					"\u041F\u0435\u0440\u0435\u0445\u0456\u0434\u043D\u0438\u0439 \u043F\u0440\u043E\u0446\u0435\u0441");
			diagram.setPainterColor(Color.MAGENTA);
		}
		return diagram;
	}
	

	public JComboBox<String> getComboBoxQueue() {
		if (comboBoxQueue == null) {
			comboBoxQueue = new JComboBox<String>();
			comboBoxQueue.setBorder(new TitledBorder(null,
					"Monitoring object selection",
					TitledBorder.CENTER, TitledBorder.BELOW_TOP, null, null));
			comboBoxQueue.addActionListener((e) -> onComboQueueAction());
		}
		return comboBoxQueue;
	}

	void onComboQueueAction() {

			JComboBox<String> cmBox = getComboBoxQueue();
			diagram.setTitleText(cmBox.getSelectedItem().toString());
		double[] array = monitor.getAverageArray();

		// Search for max vertical value
		double max = 0;
		for (Double result : array) {
			if (result > max)
				max = result;
		}
		if (max == 0)
			return;
		double k = 1;
		while (max * k < 1) {
			k *= 10;
		}
		while (max * k >= 10)
			k /= 10;
		double n = k * max;
		double[][] bounds = { { 1.5, 2, 4, 5, 7.5, 8, 10 }, { 5, 4, 4, 5, 5, 4, 5 } };
		int i = 0;
		while (n > bounds[0][i])
			i++;
		max = bounds[0][i] / k;
		String maxY;
		if (max < 10)
			maxY = String.format(Locale.ROOT, "%1.2f", max);
		else
			maxY = String.format(Locale.ROOT, "%d", (int) max);
		diagram.setVerticalMaxText(maxY);
		diagram.setGridByY((int) bounds[1][i]);
		monitor.getDiagram().clear();
		for (int j = 0; j < array.length; j++) {
			diagram.getPainter().drawOvalAtXY((float) (interval * (j + 0.5)), (float) array[j], 3, 3);
			diagram.getPainter().drawOvalAtXY((float) (interval * (j + 0.5)), (float) array[j], 2, 2);
		}
	}

	private JComboBox<IFinderRegresParm> getComboBoxRegres() {
		if (comboBoxRegres == null) {
			comboBoxRegres = new JComboBox<IFinderRegresParm>();
			comboBoxRegres.setEnabled(false);
			comboBoxRegres.setFont(new Font("Dialog", Font.PLAIN, 12));
			comboBoxRegres.setMaximumSize(new Dimension(140, 32767));
			comboBoxRegres.setMinimumSize(new Dimension(130, 22));
			comboBoxRegres.addActionListener((e) -> onComboRegresAction());
			comboBoxRegres.setBorder(new TitledBorder(
					new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)),
					"Regresion function selection",
					TitledBorder.CENTER, TitledBorder.BELOW_TOP, null, new Color(0, 0, 0)));
			comboBoxRegres.setModel(getComboRegresModel());
		}
		return comboBoxRegres;
	}
	
	protected DefaultComboBoxModel<IFinderRegresParm> 
	getComboRegresModel() {
if (comboRegresModel == null) {
	comboRegresModel = new DefaultComboBoxModel<>();		
	comboRegresModel.addElement(new RgrsProcExpCd());
	comboRegresModel.addElement(new RgrsProcExpGr());
	//comboRegresModel.addElement(new RgrsProcOverExpCd());
	comboRegresModel.addElement(new RgrsProcDelyCdGr());
}
return comboRegresModel;
}

	void onComboRegresAction() {

			JComboBox<IFinderRegresParm> cmBox = 
					getComboBoxRegres();
			IFinderRegresParm finder = 
					(IFinderRegresParm) cmBox.getSelectedItem();
      double[] array = monitor.getAverageArray();
      Double[] valueArray = new Double[array.length];
      Double[] factorArray = new Double[array.length];
      double step = monitor.getInterval();
      
    	//Виводимо результати обробки
    	diagram.clear();
    	Painter p = diagram.getPainter();
    	//Виводимо експериментальні точки
      for (int i = 0; i < array.length; i++) {
				valueArray[i] = array[i];
				factorArray[i] = step*i + step/2; 
				p.drawOvalAtXY(
						factorArray[i].floatValue(),
						valueArray[i].floatValue(), 3, 3);
				p.drawOvalAtXY(
						factorArray[i].floatValue(),
						valueArray[i].floatValue(), 2, 2);
			}
      
      // Налаштовіемо шукача параметрів функції регресії
			finder.setValueArray(valueArray);
			finder.setFactorArray(factorArray);
			//Знаходимо оптимальні параметри
			double[] parmAr = finder.findBestParm();
		 //Відмальовуємо лінію регресії
			p.placeToXY(0, 0);
			for(double x = factorArray[0]- step/2; 
					x < factorArray[factorArray.length -1]+step/2;
					x+=step/10){
						p.drawToXY((float)x, 
								(float)finder.funcRegres(x, parmAr));
			}
			// Виводимо значення параметрів на діаграму
			Graphics gc = p.getGc();
			gc.drawString(finder.parametersAsString(), 3,20);
	}
	
} // @jve:decl-index=0:visual-constraint="52,6"



