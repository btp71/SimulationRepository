package stat;

import java.util.Vector;

import javax.swing.JTextArea;


public class StatTables {

	private static int detectIndex(double n, double[] arr) {
		/* 1 to: anArray size do:[:i| (anArray at:i) >=aFloat ifTrue:[^i].]. */
		for (int i = 0; i < arr.length; i++)
			if (arr[i] >= n)
				return i;
		return arr.length-1;
	}


	public static double roundTo(double value, double roundval) {
		long multiplier = Math.round(value / roundval);
		return (roundval * multiplier);
	}



	public static String format(double x, int len, int dec) {
		// округляем
		double r = 1.0;
		for (int i = 0; i < dec; i++)
			r *= 0.1;
		float xf = (float) roundTo(x, r);
		// дописываем нули справа
		StringBuffer bs = new StringBuffer();
		bs.append(xf);
		if (dec > 0)
			while (bs.toString().indexOf(".") + dec > bs.length() - 1)
				bs.append("0");
		// добавим пробелы слева и обрежем до одинаковой длины
		if (bs.length() < len) {
			bs.reverse();
			bs.append("                     ");
			bs.setLength(len);
			bs.reverse();
		}

		return bs.toString();
	}


	public static String format(int x, int len) {
		StringBuilder bs = new StringBuilder();
		bs.append(x);
		// добавим пробелы слева и обрежем до нужной длины
		if (bs.length() < len) {
			bs.reverse();
			bs.append("                     ");
			bs.setLength(len);
			bs.reverse();
		}
		return bs.toString();
	}

	public static double kochren05(int K, int L) {
		/*
		 * K - это число степеней свободы. Обычно число экспериментов на уровне
		 * - 1 L - это количество независимых выборок одинакового размера
		 * В.Е.Гмурман. ТВ и МС, 1977, стр.325, стр.468
		 */

		double[] tmpStr1 = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 16, 36, 144, 99999 };
		double[] tmpStr2 = { 2, 3, 4, 5, 6, 7, 9, 10, 12, 15, 20, 24, 30, 40,
				60, 120, 99999 };

		int k = detectIndex((double) K, tmpStr1);
		int l = detectIndex((double) L, tmpStr2);

		//Float ret = Float.valueOf(((String[]) arr.get(l))[k]);
		return Tables.koch[l][k];
	}

	/**
	 * Расчет коэффициента корреляции. 
	 * Creation date: (21.01.2006 11:30:25)
	 */
	public static double koefKorr(double[] x1, double[] x2) {
		/* Подготовка к обработке данных */
		double s1 = 0; // Сумма элементов первой последовательности
		double s1s1 = 0; // Сумма квадратов элементов первой
		// последовательности
		double s2 = 0; // Сумма элементов второй последовательности
		double s2s2 = 0; // Сумма квадратов элементов второй
		// последовательности
		double s1s2 = 0; // Сумма произведений элементов последовательностей
		/* Обработка последовательностей */
		int size = x1.length;
		for (int i = 0; i < size; i++) {
			// Накапливаем суммы
			s1 += x1[i];
			s1s1 += x1[i] * x1[i];
			s2 += x2[i];
			s2s2 += x2[i] * x2[i];
			s1s2 += x1[i] * x2[i];
		}
		// Расчет средних значений
		s1 = s1 / size;
		s1s1 = s1s1 / size;
		s2 = s2 / size;
		s2s2 = s2s2 / size;
		s1s2 = s1s2 / size;
		// Расчет среднеквадратичных отклонений
		double sigma1 = Math.sqrt(s1s1 - s1 * s1);
		double sigma2 = Math.sqrt(s2s2 - s2 * s2);
		/* Расчет коэффициента корреляции */
		Double r;
		r = (s1s2 - s1 * s2) / (sigma1 * sigma2);
		if(r.isInfinite() || r.isNaN())
			r = 1.0;
		return r;
	}
	//v обсяг вибірки
	public static double kolmogorovSmirnov05(int v) {

		int[] n = new int[23];
		
		for (int i = 0; i < 20; i++)
			n[i] = i + 1;
		n[20] = 25;
		n[21] = 30;
		n[22] = 35;
		double[] a  = {0.97, 0.842, 0.708, 0.624, 0.565, 0.521, 0.468, 0.457
				, 0.432, 0.410, 0.391, 0.375, 0.361, 0.349, 0.338, 0.328
				, 0.318, 0.309, 0.301, 0.294, 0.27, 0.24, 0.23};
		for (int i = 0; i < n.length; i++)
			if (n[i] >= v)
				return a[i];
		return (1.36 / Math.sqrt(v));
	}

	public static double kolmSmirnovResult(double[] a, double[] t, double[] b,
			JTextArea textArea) {
		/* вычисляем отклонения и находим max */
		double max = 0;
		double[] d = new double[a.length];
		for (int i = 0; i < a.length; i++) {
			d[i] = Math.abs(a[i] - t[i]);
			if (d[i] > max)
				max = d[i];
		}
		if (textArea != null) {
			/* Готовим данные к выводу */
			// вначале округляем
			float[] ar = new float[a.length];
			float[] tr = new float[a.length];
			float[] dr = new float[a.length];
			for (int i = 0; i < a.length; i++) {
				ar[i] = (float) StatTables.roundTo(a[i], 0.01);
				tr[i] = (float) StatTables.roundTo(t[i], 0.01);
				dr[i] = (float) StatTables.roundTo(d[i], 0.01);
			}
			float[] br = new float[b.length];
			for (int i = 0; i < b.length; i++) {
				br[i] = (float) stat.StatTables.roundTo(b[i], 0.01);
			}
			// теперь удалим слева лишние интервалы содержащие 0
			int k = 1;
			int n = ar.length;
			while ((ar[k] == 0) & (tr[k] == 0)) {
				for (int j = k; j < ar.length - 1; j++) {
					ar[j] = ar[j + 1];
					tr[j] = tr[j + 1];
				}
				for (int j = k; j < br.length - 1; j++)
					br[j] = br[j + 1];
				n--;
			}
			// удалим справа лишние интервалы содержащие 1
			while ((ar[n - 2] == 1) & (tr[n - 2] == 1))
				n--;
			// ширина поля для границы интервала
			int maxLenB = 0;
			for (int i = 0; i < br.length; i++) {
				int l = String.valueOf(Math.round(br[i])).length();
				if (l > maxLenB)
					maxLenB = l;
			}
			maxLenB += 3;
			String z = " Интервалы  ";
			for (int i = 0; i < maxLenB - 3; i++) {
				z = " " + z + " ";
			}
			// сформируем табличку результатов
			String s = "Проверка  по  Колмогорову-Смирнову:\n";
			s += z + "Эксп. Теор. Откл.\n";
			for (int i = 0; i < n; i++) {
				s += format(br[i], maxLenB, 2) + " .. ";
				s += format(br[i + 1], maxLenB, 2) + "  ";
				s += format(ar[i], 4, 2) + "  ";
				s += format(tr[i], 4, 2) + "  ";
				s += format(dr[i], 4, 2) + "\n";
			}
			textArea.append(s);
		}
		return max;
	}

	//af массив абсолютнах факт частот
	// массив абсолютнах теор. частот
	public static double[] calcHi2N(double[] af, double[] at ){
		/*
		 * Особенность критерия Пирсона в том, что интервалы с частотами
		 * меньшими 5 следует объединять с соседними
		 */
		// Вначале группирум хвост массива (если надо)
		int n = af.length;
		while (af[n - 1] < 5) {
			af[n - 2] += af[n - 1];
			at[n - 2] += at[n - 1];
			n--;
		}
		// Теперь группируем начало массива
		int i = 0;
		while (i < n) {
			if (af[i] < 5) {
				af[i] += af[i + 1];
				at[i] += at[i + 1];
				for (int j = i + 1; j < n - 1; j++) {
					af[j] = af[j + 1];
					at[j] = at[j + 1];
				}
				n--;
			} else
				i++;
		}
		// Теперь считаем хи-квадрат
		double sum = 0;
		for (int j = 0; j < n; j++)
			if (at[j] != 0)
				sum += (af[j] - at[j]) * (af[j] - at[j]) / at[j];
		return new double[] {sum,n};
	}

	public static double[] pirsonResult(double[] af, // массив абсолютнах факт.
			// частот
			double[] at, // массив абсолютнах теор. частот
			double[] br, // массив границ интервалов
			JTextArea textArea, // область вывода
			int k /* число уже определенных параметров */) {
		/*
		 * Особенность критерия Пирсона в том, что интервалы с частотами
		 * меньшими 5 следует объединять с соседними
		 */
		// Вначале группирум хвост массива (если надо)
		int n = af.length;
		while (af[n - 1] < 5) {
			af[n - 2] += af[n - 1];
			at[n - 2] += at[n - 1];
			br[n - 1] = br[n];
			n--;
		}
		// Теперь группируем начало массива
		int i = 0;
		while (i < n) {
			if (af[i] < 5) {
				af[i] += af[i + 1];
				at[i] += at[i + 1];
				for (int j = i + 1; j < n - 1; j++) {
					af[j] = af[j + 1];
					at[j] = at[j + 1];
				}
				for (int j = i + 1; j < n; j++)
					br[j] = br[j + 1];
				n--;
			} else
				i++;
		}

		// ширина поля для границы интервала
		int maxLenB = 0;
		for (int j = 0; j < br.length; j++) {
			int l = String.valueOf(Math.round(br[j])).length();
			if (l > maxLenB)
				maxLenB = l;
		}
		maxLenB += 3;
		String z = " Intervals  ";
		for (int j = 0; j < maxLenB - 3; j++) {
			z = " " + z + " ";
		}

		// Выводим результаты
		if (textArea != null) {
			String s = "Pirson test:" + "\n";
			s += z + "Exp.   Theor. " + "\n";
			for (int j = 0; j < n; j++) {
				s += format(br[j], maxLenB, 2) + " .. ";
				s += format(br[j + 1], maxLenB, 2) + "  ";
				s += format(af[j], 4, 0) + "  ";
				s += format(at[j], 6, 1) + "\n";
			}
			textArea.append(s);

		}
		// Теперь считаем хи-квадрат
		double sum = 0;
		for (int j = 0; j < n; j++)
			if (at[j] != 0)
				sum += (af[j] - at[j]) * (af[j] - at[j]) / at[j];
		/* Критическое значение хи-квадрат */
		double max = hi05(n - k);
		// формируем результат
		double[] result = new double[2];
		result[0] = sum;
		result[1] = max;
		return result;
	}
	
	public static double hi05(int n) {
		return Tables.hi05()[n];
	}

	public static double student05(int ind) {
	
		int[] n = new int[11];
		for (int i = 0; i < 8; i++)
			n[i] = i + 1;
		n[8] = 13;
		n[9] = 29;

		double[] a = { 6.3, 2.9, 2.35, 2.13, 2.01, 
				1.94, 1.89, 1.86, 1.77, 1.70};
		for (int i = 0; i < n.length; i++)
			if (n[i] > ind)
				return a[i];
		return 1.64;
	}


	public static double student025(int ind) {

		int[] n = new int[11];
		for (int i = 0; i < 8; i++)
			n[i] = i + 1;
		n[8] = 13;
		n[9] = 29;

		double[] a = new double[10];
		a[0] = 12.7;
		a[1] = 4.3;
		a[2] = 3.2;
		a[3] = 2.8;
		a[4] = 2.6;
		a[5] = 2.5;
		a[6] = 2.4;
		a[7] = 2.3;
		a[8] = 2.2;
		a[9] = 2.1;
		for (int i = 0; i < n.length; i++)
			if (n[i] > ind)
				return a[i];
		return 1.96;
	}

	//Ступені свободи для більшої kMaх дисперсії і меншої kMi
	public static double fisher05(int kMax, int kMin) {	
		double[] forK1 = {1, 2, 3, 4, 5, 6, 12, 24, 99999};
		double[] forK2 = {1,2,3,4,5,6,7,8,9,10,15,24,30,120,99999};
		int k1 = detectIndex((double) kMax, forK1);
		int k2 = detectIndex((double) kMin, forK2);
		return Tables.fish[k2][k1];
		
	}

}
