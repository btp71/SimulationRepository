package rnd;

/**
 * Insert the type's description here. Creation date: (23.03.2005 10:33:36)
 * 
 * @author: Administrator
 */
public abstract class RandomGenerators implements Randomable {
	protected java.util.Random rnd;

	private boolean nextAsRound = false;

	/**
	 * У конструкторі перед створенням об'єкту rnd 
	 * створюється затримка до зміни значення системного таймеру.
	 * Це запобігає створенню генераторів, що мають однакове зерно.
	 */
	public RandomGenerators() {
		super();
		long t = System.currentTimeMillis();
		do {
		} while (t == System.currentTimeMillis());
		rnd = new java.util.Random();
	}

	/**
	 * Insert the method's description here. Creation date: (23.03.2005
	 * 11:21:36)
	 * 
	 * @return boolean
	 */
	public abstract double basicNext();
	
   // public abstract double basicNext(double r);

	

	/**
	 * Insert the method's description here. Creation date: (23.03.2005
	 * 11:22:40)
	 * 
	 * @return double
	 */
	public double next() {
		if (nextAsRound) {
			return Math.round(basicNext());
		}
		;
		return basicNext();
	}

	/**
	 * Insert the method's description here. Creation date: (28.03.2005
	 * 18:34:58)
	 * 
	 * @return double
	 */
	public double probability(double aNumber1, double aNumber2) {
		if (aNumber2 <= aNumber1) {
			return 0;
		}
		;
		return probability(aNumber2) - probability(aNumber1);
	}

	//Встановлює режим округлення згенерованих чисел
	//до цілого значення
	public void setNextAsRound(boolean newNextAsRound) {
		nextAsRound = newNextAsRound;
	}
	
	// Повертає true, якщо генератор повертає тільки цілі числа
	public boolean isNextAsRound() {
		return nextAsRound;
	}

	public abstract RandomDlg  getDialog();
	
	public Object clone() {
		try {
			return super.clone();
		} catch (CloneNotSupportedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	}
	
}
