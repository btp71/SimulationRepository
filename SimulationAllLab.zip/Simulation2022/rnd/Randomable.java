package rnd;

//Інтерфейс, що визначає протокол спілкування
//з генераторами випадкових чисел у фреймворці
public interface Randomable extends Cloneable{
	
	//Метод повертає наступне випадкове число
	double next();

	//Метод повертає значення інтегральної функції для заданого числа
	double probability(double aNumber);

	//Метод повертає імовірність того, що випадкове число 
	//потрапить в інтервал між aNumber1 та aNumber2 
	double probability(double aNumber1, double aNumber2);
	
	//Встановлює режим округлення згенерованих чисел
	//до цілого значення
	public void setNextAsRound(boolean newNextAsRound);
	
	//Має повертати true, якщо генератор формує тільки цілі числа
	public boolean isNextAsRound() ;
	
	//Повертає кількість параметрів закону розподілення
	public int getKParm();
	
	//Повертає середнє значення випадкової величини
	double average();

	//Змінює середнє значення випадкової величини
	boolean setAverage(double  m);
	
	//Повертає максимальне (приблизно) значення випадкової величини
	double max();
}
