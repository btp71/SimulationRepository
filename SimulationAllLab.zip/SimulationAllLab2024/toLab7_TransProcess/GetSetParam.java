package toLab7_TransProcess;

/**
 * Insert the type's description here. Creation date: (30.11.2005 16:30:45)
 * 
 * @author: Administrator
 */
public interface GetSetParam {
	public double getParam();

	public void setParam(double param);
}
