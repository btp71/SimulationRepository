package toLab3and4;

import java.util.HashMap;
import java.util.Map;

import process.Dispatcher;
import process.MultiActor;
import process.QueueForTransactions;
import stat.DiscretHisto;
import stat.Histo;
import stat.IHisto;
import widgets.stat.IStatisticsable;

//Клас моделі
public class Model implements IStatisticsable {
	
	// Посилання на диспетчера
	private Dispatcher dispatcher;
	// Посилання на візуальну частину
	private GUI gui;
	
	////////Актори\\\\\\\\\
	// Генератор транзакцій
	private Generator generator;
	// Обслуговуючий прилад
	private Device device;		
	//Бригада обслуговуючих пристроїв
	private MultiActor multiDevice;
	
	/////////Черги\\\\\\\\\
	// Черга транзакцій
	private QueueForTransactions<Transaction> queue;
	
	/////////Гістограми\\\\\\\\\\\\
	// Гістограма для довжини черги
	private DiscretHisto discretHistoQueue;
	// Гістограма для часу перебування у черзі
	private Histo histoTransactionWaitInQueue = new Histo();
	// Гістограма для часу обслуговування
	private Histo histoTransactionServiceTime = new Histo();
	// Гістограма для часу чекання Device
	private Histo histoWaitDevice = new Histo();

	// ////////////////////////////////////////
	// Єдиний спосіб створити модель, це викликати цей конструктор
	// Він гарантовано передає посилання на диспетчера та TransGUI
	// ////////////////////////////////////////

	public Model(Dispatcher d, GUI g) {
		if (d == null || g == null) {
			System.out
					.println("Не визначено диспетчера або TransGUI для BuldModel");
			System.out.println("Подальша робота неможлива");
			System.exit(0);
		}
		dispatcher = d;
		gui = g;
		// Передаємо акторів до стартового списку диспетчера
		componentsToStartList();
	}

	private void componentsToStartList() {
		dispatcher.addStartingActor(getGenerator());
		dispatcher.addStartingActor(getMultiDevice());

	}

	public Generator getGenerator() {
		if (generator == null) {
			generator = new Generator();
			generator.setNameForProtocol("Generator");
			generator.setModel(this);
			generator.setFinishTime(gui.getChooseDataFinishTime().getDouble());
			generator.setRnd(gui.getChooseRandomGen().getRandom());
		}
		return generator;
	}

	public QueueForTransactions<Transaction> getQueue() {
		if (queue == null) {
			queue = new QueueForTransactions<>("Queue", dispatcher,
					getDiscretHistoQueue());
		}
		return queue;
	}

	public Device getDevice() {
		if (device == null) {
			device = new Device();
			device.setNameForProtocol("Device");
			device.setHistoForActorWaitingTime(histoWaitDevice);
			device.setQueue(getQueue());
			device.setRnd(gui.getChooseRandomDev().getRandom());
			device.setFinishTime(gui.getChooseDataFinishTime().getDouble());
		}
		return device;
	}
	
	
	public MultiActor getMultiDevice() {
		if(multiDevice == null){
			multiDevice = new MultiActor();
			multiDevice.setOriginal(getDevice());
			multiDevice.setNumberOfClones(gui.getChooseDataNdevice().getInt());
			multiDevice.setNameForProtocol("Створення бригади обслуговуючих пристроїв");
		}
		return multiDevice;
	}


	public DiscretHisto getDiscretHistoQueue() {
		if (discretHistoQueue == null) {
			discretHistoQueue = new DiscretHisto();
		}
		return discretHistoQueue;
	}


	public void initForTest() {
		getQueue().setPainter(gui.getDiagramQueue().getPainter());
		if(gui.getJCheckBox().isSelected()){
			dispatcher.setProtocolFileName("Console");
		}

	}

	// Реалізація інтерфейсу IStatisticsable
	@Override
	public void initForStatistics() {

	}

	@Override
	public Map<String, IHisto> getStatistics() {
		Map<String, IHisto> map = new HashMap<>();
		map.put("Гістограма для довжини черги", getDiscretHistoQueue());
		map.put("Гістограма для часу чекання у черзі",
				histoTransactionWaitInQueue);
		map.put("Гістограма для часу простою обслуговуючого пристрою",
				getDevice().getWaitingTimeHisto());
		map.put("Гістограма для часу обслуговування",
				histoTransactionServiceTime);

		return map;
	}

    //Метод створення транзакції
	public Transaction createTransaction() {
		Transaction trz = new Transaction();
		trz.setHistoService(histoTransactionServiceTime);
		trz.setHistoInQueue(histoTransactionWaitInQueue);
		trz.setQueue(getQueue());
		return trz;
	}
}
