package toLab3and4;

import java.util.function.BooleanSupplier;

import process.Actor;
import process.ConditionNotFulfilledException;
import process.QueueForTransactions;
import rnd.Randomable;

// Клас для обслуговуючого пристрою
public class Device extends Actor {

	// Черга для тразакцій
	private QueueForTransactions<Transaction> queue;
	// Генератор часу, що витрачає прилад на обслуговування транзакції
	private Randomable rnd;
	// Час роботи генератора
	private double finishTime;

	public void rule() throws ConditionNotFulfilledException {
		// Створюємо умову, виконання якої буде чекати актор
		BooleanSupplier queueSize = () -> queue.size() > 0;
		// цикл виконання правил дії
		while (getDispatcher().getCurrentTime() <= finishTime) {
			// Перевірка наявності транзакції та чекання на її появу
			waitForCondition(queueSize, "у черзі має з'явиться транзакція");
			Transaction transaction = queue.removeFirst();
			// Імітація обробки транзакції
			holdForTime(rnd.next());
			transaction.setServiceDone(true);
		}
	}

	public void setQueue(QueueForTransactions<Transaction> queue) {
		this.queue = queue;
	}

	public void setRnd(Randomable rnd) {
		this.rnd = rnd;
	}

	public void setFinishTime(double finishTime) {
		this.finishTime = finishTime;
	}
	
}
