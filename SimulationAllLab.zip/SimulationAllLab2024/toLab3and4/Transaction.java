package toLab3and4;

import process.Actor;
import process.ConditionNotFulfilledException;
import process.QueueForTransactions;
import stat.Histo;

public class Transaction extends Actor {

	  //Черга транзакцій на обробку
		private QueueForTransactions<Transaction> queue;

	  // Гістограми для накопичення статистики
		private Histo histoInQueue;
		private Histo histoService;

	  //Ознака завершення обробки транзакції
		private boolean serviceDone; 

		@Override
	  // Правила дії транзакції
		protected void rule() throws ConditionNotFulfilledException {
			double createTime = dispatcher.getCurrentTime();
			nameForProtocol = "Транзакція " + createTime;
	    // Транзакція стає в чергу на обслуговування
			queue.add(this);
			waitForCondition(() -> !queue.contains(this), 
																"мають забрати на обслуговування");
	    // Обслуговування почалось
			histoInQueue.add(dispatcher.getCurrentTime() - createTime);
			waitForCondition(() -> serviceDone, 
	                            "мають завершити обслуговування");
	    //обслуговування закінчилось
			histoService.add(dispatcher.getCurrentTime() - createTime);
		}

	  //Методи ініціалізації транзакції
		public void setQueue(QueueForTransactions<Transaction> queue) {
			this.queue = queue;
		}
		public void setHistoInQueue(Histo histoQueue) {
			this.histoInQueue = histoQueue;
		}
		public void setHistoService(Histo histoService) {
			this.histoService = histoService;
		}

	  // Метод передачі повідомлення про закінчення обслуговування
		public void setServiceDone(boolean b) {
			this.serviceDone = b;
		}

		@Override
		public String toString() {
			return getNameForProtocol();
		}
	}

