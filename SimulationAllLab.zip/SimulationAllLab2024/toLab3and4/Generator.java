package toLab3and4;

import process.Actor;
import rnd.Randomable;

// Клас генератора заявок
public class Generator extends Actor {

	// Генератор випадкового часу створення транзакції
	private Randomable rnd;
	// Тривалість роботи генератора
	private double finishTime;
	private Model model;


	// Правила дії
	public void rule() {
		while (getDispatcher().getCurrentTime() <= finishTime) {
			holdForTime(rnd.next());
			getDispatcher().printToProtocol(
					"  " + getNameForProtocol() + " створює транзакцію.");
			dispatcher.addStartingActor(model.createTransaction());
		}
	}


	public void setRnd(Randomable rnd) {
		this.rnd = rnd;
	}


	public void setFinishTime(double finishTime) {
		this.finishTime = finishTime;
	}


	public void setModel(Model model) {
		this.model = model;
	}
	
}
